In addition to this readme, this archive file contains the following 
files:

Sample code
- index.html
- style.css
- Browsing.php
- eBaySession.php
- keys.php
- Login.php
- Logout.php
- Offer.php
- PlaceOffer.php
- sessionHeader.php
- ShowDescriptionForItem.php
- SingleItem.php
- Token.php
- VerifyToken.php
- js\JQuery.js
- js\ShowDetails.js
- js\jquery-1.1.3.1.js_uncompressed.js
- js\jquery-1.1.3.1.pack.js

Sample Source Code License 
- license.txt


For more information and instructions for using the sample code, see 
the related "Getting Started with a PHP Bidding/Buying Application" 
tutorial: 

http://developer.ebay.com/DevZone/XML/docs/HowTo/PHP_PlaceOfferGS/PHP_PlaceOfferGS_TradingShopping.html